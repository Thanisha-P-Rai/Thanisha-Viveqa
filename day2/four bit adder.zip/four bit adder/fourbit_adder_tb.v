`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 28.06.2026 23:21:20
// Design Name: 
// Module Name: fourbit_adder_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module fourbit_adder_tb;

reg [3:0] A, B;
wire [3:0] Sum;
wire Carry;

// Instantiate the module
fourbit_adder uut (
    .A(A),
    .B(B),
    .Sum(Sum),
    .Carry(Carry)
);

initial begin
    $display("A     B     | Carry Sum");
    $monitor("%b %b |   %b    %b", A, B, Carry, Sum);

    A = 4'b0000; B = 4'b0000; #10;
    A = 4'b0001; B = 4'b0010; #10;
    A = 4'b0101; B = 4'b0011; #10;
    A = 4'b1111; B = 4'b0001; #10;
    A = 4'b1010; B = 4'b0101; #10;

    $finish;
end

endmodule
